import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchText: string = '';
  search: string = '';
  show: boolean = true;
  searchData:any[] = [];
  searchString:string = '';
  constructor() { }

  ngOnInit(): void {
  }
  searchFunc(val: string) {
    this.search = val;
    if (val != '') {
      this.searchData = [];
      this.show = true;
      this.searchString = val === 'govern'? 'Building Data Trust with Strategic Data Governance' : 'No Results Found';
      this.searchData.push(this.searchString);
    } else {
      this.clear();
      this.hide();
    }
  }
  clear(){
    this.search = '';
  }
  hide() {
    
    this.show = false
  }
}

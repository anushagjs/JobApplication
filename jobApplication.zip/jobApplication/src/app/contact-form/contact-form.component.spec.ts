import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { ContactFormComponent } from './contact-form.component';
import { Contact } from '../interfaces/contact-form';

describe('ContactFormComponent', () => {
  let component: ContactFormComponent;
  let fixture: ComponentFixture<ContactFormComponent>;
  let h4: HTMLElement;

  beforeEach(() => {
     // refine the test module by declaring the test component
     TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [ContactFormComponent]
  });
    fixture = TestBed.createComponent(ContactFormComponent);
    component = fixture.componentInstance;
  
    component.ngOnInit();
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form invalid when empty', () => {
    expect(component.contactForm.valid).toBeFalsy();
 });
 it('submitting a form emits a user', () => {
  expect(component.contactForm.valid).toBeFalsy();
  component.contactForm.controls['firstName'].setValue("Poornima");
  component.contactForm.controls['lastName'].setValue("Ravindra");
  component.contactForm.controls['companyName'].setValue("Infogix HR");
  component.contactForm.controls['workEmail'].setValue("poornima.ravindra@gmail.com");
  component.contactForm.controls['phoneNumber'].setValue("1234567890");
  component.contactForm.controls['hQLocationCountry'].setValue("America");
  component.contactForm.controls['industry'].setValue("Software");
  component.contactForm.controls['comments'].setValue("This is a coding challenge for Test Automation position. Please disregard this message");
  expect(component.contactForm.valid).toBeTruthy();

  let contact: Contact;
  // Subscribe to the Observable and store the user in a local variable.
  component.contactFormLogIn.subscribe((value) => {
    contact = value
  });
  
  // Trigger the contact Submit function
  component.onSubmit();
  fixture.detectChanges();
  h4 = fixture.nativeElement.querySelector('h4');
  // Now we can check to make sure the emitted value is correct
  expect(h4.textContent).toContain('Thank you');
  
});
});

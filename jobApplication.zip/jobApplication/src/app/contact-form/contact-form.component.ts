import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Contact } from '../interfaces/contact-form';
import { FormBuilder } from '@angular/forms';
import { FormArray, Validators, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
  successMsg: boolean = false;
  Country: any = ['United States', 'Canada', 'Afghanistan'];
  Industry: any = ['Education','Energy','Financial Services'];
  @Output() contactFormLogIn = new EventEmitter<Contact>();
  contactForm: FormGroup = new FormGroup({});

  constructor(private fb: FormBuilder) { }
 

  ngOnInit(): void {
    this.contactForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      companyName:['', Validators.required],
      workEmail:['', Validators.required],
      phoneNumber :['', Validators.required],
      hQLocationCountry:['', Validators.required],
      industry:['', Validators.required],
      comments:['', Validators.required]
    });
  }

  changeCountry(e:any) {
   let countryVal = e.currentTarget.value;
    this.contactForm.setValue({'hQLocationCountry': countryVal})
  }
  changeIndustry(e:any){
    let industryVal = e.currentTarget.value;
    this.contactForm.setValue({'industry': industryVal})
  }

  onSubmit() {
    
    console.log(`Login ${this.contactForm.value}`);
    this.contactFormLogIn.emit(new Contact(this.contactForm.value.firstName,
      this.contactForm.value.lastName,
      this.contactForm.value.companyName,
      this.contactForm.value.workEmail,
      this.contactForm.value.phoneNumber,
      this.contactForm.value.hQLocationCountry,
      this.contactForm.value.industry,
      this.contactForm.value.comments));
        this.successMsg = true;
  }

}

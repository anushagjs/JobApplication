export class Contact {

    constructor(
      public firstName: string,
      public lastName: string,
      public companyName: string,
      public workEmail: string,
      public phoneNumber: string,
      public hQLocationCountry: string,
      public industry: string,
      public comments: string
    ) {  }
  
  }